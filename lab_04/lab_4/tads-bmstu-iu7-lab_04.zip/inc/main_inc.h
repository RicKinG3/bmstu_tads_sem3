#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"../inc/macrologger.h"
#include"../inc/list_operations.h"
#include"../inc/array_operations.h"
#include"../inc/expression.h"
#include"../inc/print_menu.h"
#include"../inc/time_count.h"


#ifndef MAIN_INC_H

#define MAIN_INC_H

#define OPTIONS 13
#define NO_MISTAKES 0

#define OK 0

#define ERR_UNRIGHT_OPTION -1



#endif

