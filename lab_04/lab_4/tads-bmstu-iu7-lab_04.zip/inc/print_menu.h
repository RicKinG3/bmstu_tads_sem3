#ifndef PRINT_MENU_H
#define PRINT_MENU_H

#include<stdio.h>
#include<stdlib.h>

void flush_input(void);

void print_menu(void);

#endif