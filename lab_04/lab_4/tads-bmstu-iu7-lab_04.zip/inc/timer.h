#ifndef __TIMER_H__
#define __TIMER_H__

#include <stdint.h>

uint64_t tick(void);

#endif
