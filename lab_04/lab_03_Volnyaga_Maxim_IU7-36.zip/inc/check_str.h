#ifndef __CHECK_STR_H__
#define __CHECK_STR_H__

#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>

bool check_int(char *num);

#endif